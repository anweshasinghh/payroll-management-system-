router.post('/employees', async (req, res) => {
  try {
    const { Employee_Name, Employee_Address, Employee_Phone, Employee_DOB, Department_ID } = req.body;
    const result = await pool.query(
      'INSERT INTO employees (Employee_Name, Employee_Address, Employee_Phone, Employee_DOB, Department_ID) VALUES (?, ?, ?, ?, ?)',
      [Employee_Name, Employee_Address, Employee_Phone, Employee_DOB, Department_ID || null]
    );
    res.status(201).json({ id: result.insertId });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: error.message });
  }
});

router.put('/employees/:id', async (req, res) => {
  try {
    const { Employee_Name, Employee_Address, Employee_Phone, Employee_DOB, Department_ID } = req.body;
    await pool.query(
      'UPDATE employees SET Employee_Name = ?, Employee_Address = ?, Employee_Phone = ?, Employee_DOB = ?, Department_ID = ? WHERE Employee_ID = ?',
      [Employee_Name, Employee_Address, Employee_Phone, Employee_DOB, Department_ID || null, req.params.id]
    );
    res.json({ message: 'Employee updated successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: error.message });
  }
}); 