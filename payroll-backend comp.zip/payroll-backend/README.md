# Payroll Backend

## Setup

1. Install dependencies:
   ```bash
   npm install
   ```

2. Update your MySQL credentials in `index.js`.

3. Start the server:
   ```bash
   npm start
   ```

The server will run on port 5000 by default. 